const express = require('express')
const router = express.Router()
const { sql, poolPromise } = require('./modules/config')

router.post('/companiesShow', async (req, res) => {
  try {
    const pool = await poolPromise
    const queryResult = await pool.request()
      .input('keyword', sql.NVarChar, req.body.keyword)
      .input('locale', sql.VarChar, req.headers['clientlocale'])
      .execute('basic_CompaniesShow')

    res.json({ 
      result: queryResult.recordset
    })
  } catch (err) {
    res.status(500)
    res.send(err.message)
  }
})
router.post('/companyNew', async (req, res) => {
  try {
    let form = req.body.form
    const pool = await poolPromise
    const queryResult = await pool.request()
      .input('ID', sql.NVarChar, form.ID)
      .input('Name', sql.NVarChar, form.Name)
      .input('Principal', sql.NVarChar, form.Principal)
      .input('UniformNumber', sql.NVarChar, form.UniformNumber)
      .input('Tel1', sql.NVarChar, form.Tel1)
      .input('Tel2', sql.NVarChar, form.Tel2)
      .input('StartDate', sql.NVarChar, form.StartDate)
      .input('EndDate', sql.NVarChar, form.EndDate)
      .input('Status', sql.VarChar, form.Status)
      .input('Country', sql.VarChar, form.Country)
      .input('City', sql.VarChar, form.City)
      .input('Post', sql.VarChar, form.Post)
      .input('Address', sql.NVarChar, form.Address)
      .input('refKind', sql.VarChar, form.refKind)
      .input('Referrer', sql.NVarChar, form.Referrer)
      .input('EmployeeID', sql.NVarChar, form.EmployeeID)
      .input('Nickname', sql.NVarChar, form.Nickname)
      .execute('basic_CompanyNew')

      if (queryResult.recordset[0].code !== 200 ){
        throw Error(queryResult.recordset[0].message)
      }
      
    res.json({ 
      result: queryResult.recordset
    })
  } catch (err) {
    res.status(500)
    res.send(err.message)
  }
})
router.post('/companyEdit', async (req, res) => {
  try {
    let form = req.body.form
    const pool = await poolPromise
    const queryResult = await pool.request()
      .input('ID', sql.NVarChar, form.ID)
      .input('Name', sql.NVarChar, form.Name)
      .input('Principal', sql.NVarChar, form.Principal)
      .input('UniformNumber', sql.NVarChar, form.UniformNumber)
      .input('Tel1', sql.NVarChar, form.Tel1)
      .input('Tel2', sql.NVarChar, form.Tel2)
      .input('StartDate', sql.NVarChar, form.StartDate)
      .input('EndDate', sql.NVarChar, form.EndDate)
      .input('Status', sql.VarChar, form.Status)
      .input('Country', sql.VarChar, form.Country)
      .input('City', sql.VarChar, form.City)
      .input('Post', sql.VarChar, form.Post)
      .input('Address', sql.NVarChar, form.Address)
      .input('refKind', sql.VarChar, form.refKind)
      .input('Referrer', sql.NVarChar, form.Referrer)
      .input('EmployeeID', sql.NVarChar, form.EmployeeID)
      .input('Nickname', sql.NVarChar, form.Nickname)
      .execute('basic_CompanyEdit')

      if (queryResult.recordset[0].code !== 200 ){
        throw Error(queryResult.recordset[0].message)
      }
      
    res.json({ 
      result: queryResult.recordset
    })
  } catch (err) {
    res.status(500)
    res.send(err.message)
  }
})

router.post('/customersShow', async (req, res) => {
  try {
    const pool = await poolPromise
    const queryResult = await pool.request()
      .input('keyword', sql.NVarChar, req.body.keyword)
      .input('locale', sql.VarChar, req.headers['clientlocale'])
      .execute('basic_CustomersShow')
    res.json({ 
      result: queryResult.recordset
    })
  } catch (err) {
    res.status(500)
    res.send(err.message)
  }
})
router.post('/customerNew', async (req, res) => {
  try {
    let form = req.body.form
    const pool = await poolPromise
    const queryResult = await pool.request()
      .input('ID', sql.NVarChar, form.ID)
      .input('Name', sql.NVarChar, form.Name)
      .input('NameEnglish', sql.NVarChar, form.NameEnglish)
      .input('AgentID', sql.NVarChar, form.AgentID)
      .input('AgentName', sql.NVarChar, form.AgentName)
      .input('AgentCountry', sql.VarChar, form.AgentCountry)
      .input('AgentCity', sql.VarChar, form.AgentCity)
      .input('AgentPost', sql.VarChar, form.AgentPost)
      .input('AgentAddress', sql.NVarChar, form.AgentAddress)     
      .input('TelHome', sql.NVarChar, form.TelHome)
      .input('TelMobile', sql.NVarChar, form.TelMobile)
      .input('Country', sql.VarChar, form.Country)
      .input('City', sql.VarChar, form.City)
      .input('Post', sql.VarChar, form.Post)
      .input('Address', sql.NVarChar, form.Address)
      .input('EMail', sql.NVarChar, form.EMail)
      .input('EmployeeID', sql.NVarChar, form.EmployeeID)
      .input('Birth', sql.NVarChar, form.Birth)
      .input('Gender', sql.VarChar, form.Gender)
      .input('Status', sql.VarChar, form.Status)
      .input('refKind', sql.NVarChar, form.refKind)
      .input('Referrer', sql.NVarChar, form.Referrer)
      .execute('basic_CustomerNew')

      if (queryResult.recordset[0].code !== 200 ){
        throw Error(queryResult.recordset[0].message)
      }
      
    res.json({ 
      result: queryResult.recordset
    })
  } catch (err) {
    res.status(500)
    res.send(err.message)
  }
})
router.post('/customerEdit', async (req, res) => {
  try {
    let form = req.body.form
    const pool = await poolPromise
    const queryResult = await pool.request()
      .input('ID', sql.NVarChar, form.ID)
      .input('Name', sql.NVarChar, form.Name)
      .input('NameEnglish', sql.NVarChar, form.NameEnglish)
      .input('AgentID', sql.NVarChar, form.AgentID)
      .input('AgentName', sql.NVarChar, form.AgentName)
      .input('AgentCountry', sql.VarChar, form.AgentCountry)
      .input('AgentCity', sql.VarChar, form.AgentCity)
      .input('AgentPost', sql.VarChar, form.AgentPost)
      .input('AgentAddress', sql.NVarChar, form.AgentAddress)     
      .input('TelHome', sql.NVarChar, form.TelHome)
      .input('TelMobile', sql.NVarChar, form.TelMobile)
      .input('Country', sql.VarChar, form.Country)
      .input('City', sql.VarChar, form.City)
      .input('Post', sql.VarChar, form.Post)
      .input('Address', sql.NVarChar, form.Address)
      .input('EMail', sql.NVarChar, form.EMail)
      .input('EmployeeID', sql.NVarChar, form.EmployeeID)
      .input('Birth', sql.NVarChar, form.Birth)
      .input('Gender', sql.VarChar, form.Gender)
      .input('Status', sql.VarChar, form.Status)
      .input('refKind', sql.VarChar, form.refKind)
      .input('Referrer', sql.NVarChar, form.Referrer)
      .execute('basic_CustomerEdit')

      if (queryResult.recordset[0].code !== 200 ){
        throw Error(queryResult.recordset[0].message)
      }
      
    res.json({ 
      result: queryResult.recordset
    })
  } catch (err) {
    res.status(500)
    res.send(err.message)
  }
})

router.post('/employeesShow', async (req, res) => {
  try {
    const pool = await poolPromise
    const queryResult = await pool.request()
      .input('keyword', sql.NVarChar, req.body.keyword)
      .input('locale', sql.VarChar, req.headers['clientlocale'])
      .execute('basic_EmployeesShow')
      
    res.json({ 
      result: queryResult.recordset
    })
  } catch (err) {
    res.status(500)
    res.send(err.message)
  }
})
router.post('/employeeNew', async (req, res) => {
  try {
    let form = req.body.form
    const pool = await poolPromise
    const queryResult = await pool.request()
      .input('ID', sql.NVarChar, form.ID)
      .input('Name', sql.NVarChar, form.Name)
      .input('TelHome', sql.NVarChar, form.TelHome)
      .input('TelMobile', sql.NVarChar, form.TelMobile)
      .input('Grade', sql.VarChar, form.Grade)
      .input('CompanyID', sql.NVarChar, form.CompanyID)
      .input('StartDate', sql.NVarChar, form.StartDate)
      .input('EndDate', sql.NVarChar, form.EndDate)
      .input('Status', sql.VarChar, form.Status)
      .input('Country', sql.VarChar, form.Country)
      .input('City', sql.VarChar, form.City)
      .input('Post', sql.VarChar, form.Post)
      .input('Address', sql.NVarChar, form.Address)
      .input('EMail', sql.NVarChar, form.EMail)
      .input('ParentID', sql.NVarChar, form.ParentID)
      .input('Memo', sql.NVarChar, form.Memo)
      .execute('basic_EmployeeNew')

      if (queryResult.recordset[0].code !== 200 ){
        throw Error(queryResult.recordset[0].message)
      }
      
    res.json({ 
      result: queryResult.recordset
    })
  } catch (err) {
    res.status(500)
    res.send(err.message)
  }
})
router.post('/employeeEdit', async (req, res) => {
  try {
    let form = req.body.form
    const pool = await poolPromise
    const queryResult = await pool.request()
      .input('ID', sql.NVarChar, form.ID)
      .input('Name', sql.NVarChar, form.Name)
      .input('TelHome', sql.NVarChar, form.TelHome)
      .input('TelMobile', sql.NVarChar, form.TelMobile)
      .input('Grade', sql.VarChar, form.Grade)
      .input('CompanyID', sql.NVarChar, form.CompanyID)
      .input('StartDate', sql.NVarChar, form.StartDate)
      .input('EndDate', sql.NVarChar, form.EndDate)
      .input('Status', sql.NVarChar, form.Status)
      .input('Country', sql.VarChar, form.Country)
      .input('City', sql.VarChar, form.City)
      .input('Post', sql.VarChar, form.Post)
      .input('Address', sql.NVarChar, form.Address)
      .input('EMail', sql.NVarChar, form.EMail)
      .input('ParentID', sql.NVarChar, form.ParentID)
      .input('Memo', sql.NVarChar, form.Memo)
      .execute('basic_EmployeeEdit')

      if (queryResult.recordset[0].code !== 200 ){
        throw Error(queryResult.recordset[0].message)
      }
      
    res.json({ 
      result: queryResult.recordset
    })
  } catch (err) {
    res.status(500)
    res.send(err.message)
  }
})

router.post('/productsShow', async (req, res) => {
  try {
    const pool = await poolPromise
    const queryResult = await pool.request()
      .input('keyword', sql.NVarChar, req.body.keyword)
      .input('locale', sql.VarChar, req.headers['clientlocale'])
      .execute('basic_ProductsShow')
      
    res.json({ 
      result: queryResult.recordset
    })
  } catch (err) {
    res.status(500)
    res.send(err.message)
  }
})
router.post('/productNew', async (req, res) => {
  try {
    let form = req.body.form
    const pool = await poolPromise
    const queryResult = await pool.request()
      .input('ID', sql.NVarChar, form.ID)
      .input('Name', sql.NVarChar, form.Name)
      .input('AccountingID', sql.NVarChar, form.AccountingID)
      .input('AccountingName', sql.NVarChar, form.AccountingName)
      .input('Qty', sql.SmallInt, form.Qty)
      .input('Unit', sql.VarChar, form.Unit)
      .input('Price', sql.Decimal, form.Price)
      .input('Cost', sql.Decimal, form.Cost)
      .input('Category1', sql.VarChar, form.Category1)
      .input('Category2', sql.VarChar, form.Category2)
      .input('Category3', sql.VarChar, form.Category3)
      .input('Status', sql.VarChar, form.Status)
      .execute('basic_ProductNew')

      if (queryResult.recordset[0].code !== 200 ){
        throw Error(queryResult.recordset[0].message)
      }
      
    res.json({ 
      result: queryResult.recordset
    })
  } catch (err) {
    res.status(500)
    res.send(err.message)
  }
})
router.post('/productEdit', async (req, res) => {
  try {
    let form = req.body.form
    const pool = await poolPromise
    const queryResult = await pool.request()
      .input('ID', sql.NVarChar, form.ID)
      .input('Name', sql.NVarChar, form.Name)
      .input('AccountingID', sql.NVarChar, form.AccountingID)
      .input('AccountingName', sql.NVarChar, form.AccountingName)
      .input('Qty', sql.SmallInt, form.Qty)
      .input('Unit', sql.VarChar, form.Unit)
      .input('Price', sql.Decimal, form.Price)
      .input('Cost', sql.Decimal, form.Cost)
      .input('Category1', sql.VarChar, form.Category1)
      .input('Category2', sql.VarChar, form.Category2)
      .input('Category3', sql.VarChar, form.Category3)
      .input('Status', sql.VarChar, form.Status)
      .execute('basic_ProductEdit')

      if (queryResult.recordset[0].code !== 200 ){
        throw Error(queryResult.recordset[0].message)
      }
      
    res.json({ 
      result: queryResult.recordset
    })
  } catch (err) {
    res.status(500)
    res.send(err.message)
  }
})
router.post('/productBOMNew', async (req, res) => {
  try {
    let form = req.body.form
    const pool = await poolPromise
    const queryResult = await pool.request()
      .input('ProductID', sql.NVarChar, form.ProductID)
      .input('Seq', sql.NVarChar, form.Seq)
      .input('SubID', sql.NVarChar, form.SubID)
      .input('Qty', sql.SmallInt, form.Qty)
      .execute('basic_ProductBOMNew')

      if (queryResult.recordset[0].code !== 200 ){
        throw Error(queryResult.recordset[0].message)
      }
      
    res.json({ 
      result: queryResult.recordset
    })
  } catch (err) {
    res.status(500)
    res.send(err.message)
  }
})
router.post('/productBOMEdit', async (req, res) => {
  try {
    let form = req.body.form
    const pool = await poolPromise
    const queryResult = await pool.request()
      .input('ProductID', sql.NVarChar, form.ProductID)
      .input('Seq', sql.NVarChar, form.Seq)
      .input('SubID', sql.NVarChar, form.SubID)
      .input('Qty', sql.SmallInt, form.Qty)
      .execute('basic_ProductBOMEdit')

      if (queryResult.recordset[0].code !== 200 ){
        throw Error(queryResult.recordset[0].message)
      }
      
    res.json({ 
      result: queryResult.recordset
    })
  } catch (err) {
    res.status(500)
    res.send(err.message)
  }
})
router.post('/productBOMDelete', async (req, res) => {
  try {
    let form = req.body.form
    const pool = await poolPromise
    const queryResult = await pool.request()
      .input('ProductID', sql.NVarChar, form.ProductID)
      .input('Seq', sql.NVarChar, form.Seq)
      .input('SubID', sql.NVarChar, form.SubID)
      .input('Qty', sql.SmallInt, form.Qty)
      .execute('basic_ProductBOMDelete')

      if (queryResult.recordset[0].code !== 200 ){
        throw Error(queryResult.recordset[0].message)
      }
      
    res.json({ 
      result: queryResult.recordset
    })
  } catch (err) {
    res.status(500)
    res.send(err.message)
  }
})

router.post('/projectsShow', async (req, res) => {
  try {
    const pool = await poolPromise
    const queryResult = await pool.request()
      .input('keyword', sql.NVarChar, req.body.keyword)
      .input('locale', sql.VarChar, req.headers['clientlocale'])
      .execute('basic_ProjectsShow')

    res.json({ 
      result: queryResult.recordset
    })
  } catch (err) {
    res.status(500)
    res.send(err.message)
  }
})
router.post('/projectNew', async (req, res) => {
  try {
    let form = req.body.form
    const pool = await poolPromise
    const queryResult = await pool.request()
      .input('ID', sql.NVarChar, form.ID)
      .input('Name', sql.NVarChar, form.Name)
      .input('StartDate', sql.Date, form.StartDate)
      .input('EndDate', sql.Date, form.EndDate)
      .input('Price', sql.Decimal, form.Price)
      .execute('basic_ProjectNew')

      if (queryResult.recordset[0].code !== 200 ){
        throw Error(queryResult.recordset[0].message)
      }
      
    res.json({ 
      result: queryResult.recordset
    })
  } catch (err) {
    res.status(500)
    res.send(err.message)
  }
})
router.post('/projectEdit', async (req, res) => {
  try {
    let form = req.body.form
    const pool = await poolPromise
    const queryResult = await pool.request()
      .input('ID', sql.NVarChar, form.ID)
      .input('Name', sql.NVarChar, form.Name)
      .input('StartDate', sql.Date, form.StartDate)
      .input('EndDate', sql.Date, form.EndDate)
      .input('Price', sql.Decimal, form.Price)
      .execute('basic_ProjectEdit')

      if (queryResult.recordset[0].code !== 200 ){
        throw Error(queryResult.recordset[0].message)
      }
      
    res.json({ 
      result: queryResult.recordset
    })
  } catch (err) {
    res.status(500)
    res.send(err.message)
  }
})
router.post('/projectDetailNew', async (req, res) => {
  try {
    let form = req.body.form
    const pool = await poolPromise
    const queryResult = await pool.request()
      .input('ProjectID', sql.NVarChar, form.ProjectID)
      .input('Seq', sql.NVarChar, form.Seq)
      .input('ProductID', sql.NVarChar, form.ProductID)
      .input('Price', sql.Decimal, form.Price)     
      .input('Qty', sql.SmallInt, form.Qty)
      .execute('basic_ProjectDetailNew')

      if (queryResult.recordset[0].code !== 200 ){
        throw Error(queryResult.recordset[0].message)
      }
      
    res.json({ 
      result: queryResult.recordset
    })
  } catch (err) {
    res.status(500)
    res.send(err.message)
  }
})
router.post('/projectDetailEdit', async (req, res) => {
  try {
    let form = req.body.form
    const pool = await poolPromise
    const queryResult = await pool.request()
      .input('ProjectID', sql.NVarChar, form.ProjectID)
      .input('Seq', sql.NVarChar, form.Seq)
      .input('ProductID', sql.NVarChar, form.ProductID)
      .input('Price', sql.Decimal, form.Price)     
      .input('Qty', sql.SmallInt, form.Qty)
      .execute('basic_ProjectDetailEdit')

      if (queryResult.recordset[0].code !== 200 ){
        throw Error(queryResult.recordset[0].message)
      }
      
    res.json({ 
      result: queryResult.recordset
    })
  } catch (err) {
    res.status(500)
    res.send(err.message)
  }
})
router.post('/projectDetailDelete', async (req, res) => {
  try {
    let form = req.body.form
    const pool = await poolPromise
    const queryResult = await pool.request()
      .input('ProjectID', sql.NVarChar, form.ProjectID)
      .input('Seq', sql.NVarChar, form.Seq)
      .input('ProductID', sql.NVarChar, form.ProductID)
      .input('Price', sql.Decimal, form.Price)     
      .input('Qty', sql.SmallInt, form.Qty)
      .execute('basic_ProjectDetailDelete')

      if (queryResult.recordset[0].code !== 200 ){
        throw Error(queryResult.recordset[0].message)
      }
      
    res.json({ 
      result: queryResult.recordset
    })
  } catch (err) {
    res.status(500)
    res.send(err.message)
  }
})
router.post('/projectPBonusNew', async (req, res) => {
  try {
    let form = req.body.form
    const pool = await poolPromise
    const queryResult = await pool.request()
      .input('ProjectID', sql.NVarChar, form.ProjectID)
      .input('Seq', sql.NVarChar, form.Seq)
      .input('Grade', sql.VarChar, form.Grade)
      .input('Percentage', sql.Decimal(10,2), form.Percentage)
      .execute('basic_ProjectPBonusNew')

      if (queryResult.recordset[0].code !== 200 ){
        throw Error(queryResult.recordset[0].message)
      }
           
    res.json({ 
      result: queryResult.recordset
    })
  } catch (err) {
    res.status(500)
    res.send(err.message)
  }
})
router.post('/projectPBonusEdit', async (req, res) => {
  try {
    let form = req.body.form
    const pool = await poolPromise
    const queryResult = await pool.request()
    .input('ProjectID', sql.NVarChar, form.ProjectID)
    .input('Seq', sql.NVarChar, form.Seq)
    .input('Grade', sql.VarChar, form.Grade)
    .input('Percentage', sql.Decimal(10,2), form.Percentage)
      .execute('basic_ProjectPBonusEdit')

      if (queryResult.recordset[0].code !== 200 ){
        throw Error(queryResult.recordset[0].message)
      }
      
    res.json({ 
      result: queryResult.recordset
    })
  } catch (err) {
    res.status(500)
    res.send(err.message)
  }
})
router.post('/projectPBonusDelete', async (req, res) => {
  try {
    let form = req.body.form
    const pool = await poolPromise
    const queryResult = await pool.request()
    .input('ProjectID', sql.NVarChar, form.ProjectID)
    .input('Seq', sql.NVarChar, form.Seq)
    .input('Grade', sql.VarChar, form.Grade)
    .input('Percentage', sql.Decimal(10,2), form.Percentage)
      .execute('basic_ProjectPBonusDelete')

      if (queryResult.recordset[0].code !== 200 ){
        throw Error(queryResult.recordset[0].message)
      }
      
    res.json({ 
      result: queryResult.recordset
    })
  } catch (err) {
    res.status(500)
    res.send(err.message)
  }
})
router.post('/projectSuperBonusNew', async (req, res) => {
  try {
    let form = req.body.form
    const pool = await poolPromise
    const queryResult = await pool.request()
      .input('ProjectID', sql.NVarChar, form.ProjectID)
      .input('Seq', sql.NVarChar, form.Seq)
      .input('Price', sql.Decimal, form.Price)
      .input('Percentage', sql.Decimal(10,2), form.Percentage)
      .execute('basic_ProjectSuperBonusNew')

      if (queryResult.recordset[0].code !== 200 ){
        throw Error(queryResult.recordset[0].message)
      }
          
    res.json({ 
      result: queryResult.recordset
    })
  } catch (err) {
    res.status(500)
    res.send(err.message)
  }
})
router.post('/projectSuperBonusEdit', async (req, res) => {
  try {
    let form = req.body.form
    const pool = await poolPromise
    const queryResult = await pool.request()
    .input('ProjectID', sql.NVarChar, form.ProjectID)
    .input('Seq', sql.NVarChar, form.Seq)
    .input('Price', sql.Decimal, form.Price)
    .input('Percentage', sql.Decimal(10,2), form.Percentage)
      .execute('basic_ProjectSuperBonusEdit')

      if (queryResult.recordset[0].code !== 200 ){
        throw Error(queryResult.recordset[0].message)
      }
      
    res.json({ 
      result: queryResult.recordset
    })
  } catch (err) {
    res.status(500)
    res.send(err.message)
  }
})
router.post('/projectSuperBonusDelete', async (req, res) => {
  try {
    let form = req.body.form
    const pool = await poolPromise
    const queryResult = await pool.request()
    .input('ProjectID', sql.NVarChar, form.ProjectID)
    .input('Seq', sql.NVarChar, form.Seq)
    .input('Price', sql.Decimal, form.Price)
    .input('Percentage', sql.Decimal(10,2), form.Percentage)
      .execute('basic_ProjectSuperBonusDelete')

      if (queryResult.recordset[0].code !== 200 ){
        throw Error(queryResult.recordset[0].message)
      }
      
    res.json({ 
      result: queryResult.recordset
    })
  } catch (err) {
    res.status(500)
    res.send(err.message)
  }
})

router.post('/checkValidate', async (req, res) => {
  try {
    const pool = await poolPromise
    const queryResult = await pool.request()
      .input('type', sql.NVarChar, req.body.type)
      .input('ID', sql.VarChar, req.body.ID)
      .execute('basic_CheckValidate')
      
    res.json({
      result: queryResult.recordset
    })
  } catch (err) {
    res.status(500)
    res.send(err.message)
  }
})
router.post('/getDropdownList', async (req, res) => {
  try {
    const pool = await poolPromise
    const queryResult = await pool.request()
      .input('type', sql.NVarChar, req.body.type)
      .input('locale', sql.VarChar, req.headers['clientlocale'])
      .execute('basic_GetDropdownList')
      
    res.json({
      result: queryResult.recordset
    })
  } catch (err) {
    res.status(500)
    res.send(err.message)
  }
})
router.post('/getObject', async (req, res) => {
  try {
    const pool = await poolPromise
    const queryResult = await pool.request()
      .input('type', sql.NVarChar, req.body.type)
      .input('ID', sql.NVarChar, req.body.ID)
      .input('locale', sql.VarChar, req.headers['clientlocale'])
      .execute('basic_GetObject')
      
    res.json({
      result: queryResult.recordset
    })
  } catch (err) {
    res.status(500)
    res.send(err.message)
  }
})

module.exports = router